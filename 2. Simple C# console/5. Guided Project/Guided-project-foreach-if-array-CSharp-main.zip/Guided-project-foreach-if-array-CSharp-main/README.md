# Guided-project-foreach-if-array-CSharp
Starter and Solution code for the Guided project: "Develop foreach and if-elseif-else structures to process array data in C#" from the Microsoft Learn collection "Getting started with C#"
